package com.woniu.cinema.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.woniu.common.annotation.Excel;
import com.woniu.common.core.domain.BaseEntity;

/**
 * 演员信息对象 tb_actor
 * 
 * @author yy
 * @date 2021-01-01
 */
public class Actor extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 演员id(主键) */
    private Long actorId;

    /** 演员姓名 */
    @Excel(name = "演员姓名")
    private String actorName;

    /** 演员照片 */
    @Excel(name = "演员照片")
    private String actorImg;

    public void setActorId(Long actorId) 
    {
        this.actorId = actorId;
    }

    public Long getActorId() 
    {
        return actorId;
    }
    public void setActorName(String actorName) 
    {
        this.actorName = actorName;
    }

    public String getActorName() 
    {
        return actorName;
    }
    public void setActorImg(String actorImg) 
    {
        this.actorImg = actorImg;
    }

    public String getActorImg() 
    {
        return actorImg;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("actorId", getActorId())
            .append("actorName", getActorName())
            .append("actorImg", getActorImg())
            .toString();
    }
}
