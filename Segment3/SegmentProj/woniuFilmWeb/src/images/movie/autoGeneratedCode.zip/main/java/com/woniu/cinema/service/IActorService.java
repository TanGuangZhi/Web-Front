package com.woniu.cinema.service;

import java.util.List;
import com.woniu.cinema.domain.Actor;

/**
 * 演员信息Service接口
 * 
 * @author yy
 * @date 2021-01-01
 */
public interface ActorService
{
    /**
     * 查询演员信息
     * 
     * @param actorId 演员信息ID
     * @return 演员信息
     */
    public Actor selectActorById(Long actorId);

    /**
     * 查询演员信息列表
     * 
     * @param actor 演员信息
     * @return 演员信息集合
     */
    public List<Actor> selectActorList(Actor actor);

    /**
     * 新增演员信息
     * 
     * @param actor 演员信息
     * @return 结果
     */
    public int insertActor(Actor actor);

    /**
     * 修改演员信息
     * 
     * @param actor 演员信息
     * @return 结果
     */
    public int updateActor(Actor actor);

    /**
     * 批量删除演员信息
     * 
     * @param actorIds 需要删除的演员信息ID
     * @return 结果
     */
    public int deleteActorByIds(Long[] actorIds);

    /**
     * 删除演员信息信息
     * 
     * @param actorId 演员信息ID
     * @return 结果
     */
    public int deleteActorById(Long actorId);
}
