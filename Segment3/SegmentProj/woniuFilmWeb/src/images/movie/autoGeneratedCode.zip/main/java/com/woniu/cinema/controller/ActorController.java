package com.woniu.cinema.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.woniu.common.annotation.Log;
import com.woniu.common.core.controller.BaseController;
import com.woniu.common.core.domain.AjaxResult;
import com.woniu.common.enums.BusinessType;
import com.woniu.cinema.domain.Actor;
import com.woniu.cinema.service.IActorService;
import com.woniu.common.utils.poi.ExcelUtil;
import com.woniu.common.core.page.TableDataInfo;

/**
 * 演员信息Controller
 * 
 * @author yy
 * @date 2021-01-01
 */
@RestController
@RequestMapping("/cinema/actor")
public class ActorController extends BaseController
{
    @Autowired
    private IActorService actorService;

    /**
     * 查询演员信息列表
     */
    @GetMapping("/list")
    public TableDataInfo list(Actor actor)
    {
        startPage();
        List<Actor> list = actorService.selectActorList(actor);
        return getDataTable(list);
    }

    /**
     * 导出演员信息列表
     */
    @Log(title = "演员信息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(Actor actor)
    {
        List<Actor> list = actorService.selectActorList(actor);
        ExcelUtil<Actor> util = new ExcelUtil<Actor>(Actor.class);
        return util.exportExcel(list, "actor");
    }

    /**
     * 获取演员信息详细信息
     */
    @GetMapping(value = "/{actorId}")
    public AjaxResult getInfo(@PathVariable("actorId") Long actorId)
    {
        return AjaxResult.success(actorService.selectActorById(actorId));
    }

    /**
     * 新增演员信息
     */
    @Log(title = "演员信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Actor actor)
    {
        return toAjax(actorService.insertActor(actor));
    }

    /**
     * 修改演员信息
     */
    @Log(title = "演员信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Actor actor)
    {
        return toAjax(actorService.updateActor(actor));
    }

    /**
     * 删除演员信息
     */
    @Log(title = "演员信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{actorIds}")
    public AjaxResult remove(@PathVariable Long[] actorIds)
    {
        return toAjax(actorService.deleteActorByIds(actorIds));
    }
}
