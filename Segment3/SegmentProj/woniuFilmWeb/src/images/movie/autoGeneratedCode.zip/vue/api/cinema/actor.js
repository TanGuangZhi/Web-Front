import request from '@/utils/request'

// 查询演员信息列表
export function listActor(query) {
  return request({
    url: '/cinema/actor/list',
    method: 'get',
    params: query
  })
}

// 查询演员信息详细
export function getActor(actorId) {
  return request({
    url: '/cinema/actor/' + actorId,
    method: 'get'
  })
}

// 新增演员信息
export function addActor(data) {
  return request({
    url: '/cinema/actor',
    method: 'post',
    data: data
  })
}

// 修改演员信息
export function updateActor(data) {
  return request({
    url: '/cinema/actor',
    method: 'put',
    data: data
  })
}

// 删除演员信息
export function delActor(actorId) {
  return request({
    url: '/cinema/actor/' + actorId,
    method: 'delete'
  })
}

// 导出演员信息
export function exportActor(query) {
  return request({
    url: '/cinema/actor/export',
    method: 'get',
    params: query
  })
}