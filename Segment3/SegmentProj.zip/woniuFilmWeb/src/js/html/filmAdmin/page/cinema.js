/*
 * @Author: TanGuangZhi
 * @Date: 2022-01-20 09:13:25 Thu
 * @LastEditTime: 2022-01-20 19:50:43 Thu
 * @LastEditors: TanGuangZhi
 * @Description: 
 * @KeyWords: NodeJs, Express, MongoDB
 */
import "@css/bootstrap.css";
import "@js/bootstrap";

import { cinemaPackage } from "../../../util/cinemaPackage.js";
