/*
 * @Author: TanGuangZhi
 * @Date: 2022-01-17 19:48:08 Mon
 * @LastEditTime: 2022-01-20 09:47:47 Thu
 * @LastEditors: TanGuangZhi
 * @Description: 
 * @KeyWords: NodeJs, Express, MongoDB
 */
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap";
import userPackage from "../../../util/userPackage.js";
