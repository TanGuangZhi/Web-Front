import "../css/common1.css";
import "../css/cinemas-cinema.b26baff1.css";