/*
 * @Author: TanGuangZhi
 * @Date: 2022-02-09 12:44:19 Wed
 * @LastEditTime: 2022-02-09 13:54:34 Wed
 * @LastEditors: TanGuangZhi
 * @Description: 
 * @KeyWords: NodeJs, Express, MongoDB
 */
let sendSms = require('./util/sendCheckMessage.js');
sendSms.sendSms()
